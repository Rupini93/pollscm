multiple developers
  UI
  DB
  JAVA
  mobileapp 
  
  code push into a common location remote repository github
  integrate code for relase product 
  Q) when do i combine or integrate
      1 if i  do it at the last 
         big bang integration
      2 if i do it from the beging it might fails 
        CI  
    Integration: 
       integrate workdone by multiple developers 
      * integrate code combile almost hourly and daily 
        * build code
        * execute unit 
        * automations 
     * if all these case is suuccess full my integration successfull
     * if anything fails my intergation faily 
       when ever my integration is fail i will send information to all my team members

       That is there from day one 

Steps:
  1 we get the code from version control system (git)
  2 execute the build 
      java:
         maven , ant , gradle
      .net:
        Msbuild
        nuget
  3 execute unit test
  4 execute some automation tests
  5 execute some other test
  6 execute static code analyis
     sonarqube
  7 store artifact (war , jar , ear , dll,exe)   CI
     jfrog artifactory
     nexus
--------------
  8 deploy application in test dev env
     if test results success
  9 deploy application into internal server  (pre prod or staging or UAT)
  10 deploy production 
 ------------------------ ci/cd


 what is diff b/w continous delivery and continous deployment  

 CICD: cron jobs 
      we need to apply intelgence 
  jenkins     cloud bees
  teamcity
  travis 
  go cd
  bamboo        atlasian
  gitlab     
  aws code pipeline  aws 
  azuredevops        azure
  circle ci

Jenkins:
-------
* how to install jenkins
     three ways to install jenkins
         1 standalone:  not recomended
          -----
          sudo apt-get update
          sudo apt-get install openjdk-8-jdk -y
          download jenkins.war file
             http://mirror.serverion.com/jenkins/war-stable/2.222.4/jenkins.war
          execute war 
            java -jar jenkins.war
            
         2 jenkins as a service: 
             * install jdk8
            sudo apt-get update
            sudo apt-get install openjdk-8-jdk -y
            wget -q -O - https://pkg.jenkins.io/debian-stable/jenkins.io.key |    sudo     apt-key add -
            sudo sh -c 'echo deb https://pkg.jenkins.io/debian-stable binary/ > \
                  /etc/apt/sources.list.d/jenkins.list'
             sudo apt-get update
             sudo apt-get install jenkins -y

            
         3 jenkins application deploy tomcat (webapps):
                
            


        