EBS Volume:
 * launch EC2 machine (us-west-2a)
 * create EBS volume  (us-west-2a)
 * volume attach to EC2 machine
 * login into EC2 machine
 * create mount 
   Reference: https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-using-volumes.html

* detach volume:
   * unmount 
   * detach volume

## windows:
  Reference: https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/ebs-using-volumes.html
  